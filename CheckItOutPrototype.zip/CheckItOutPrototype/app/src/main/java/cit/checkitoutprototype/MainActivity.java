package cit.checkitoutprototype;

import android.app.Activity;
import android.content.ContentProvider;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;


public class MainActivity extends Activity{

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);

            setContentView(R.layout.activity_main);
        }

        public void ImportFile(View w){
            Intent intent = new Intent(MainActivity.this, ImportActivity.class);
            startActivity(intent);}
        public void RecordFile(View w){
            Intent intent = new Intent(MainActivity.this, RecordActivity.class);
            startActivity(intent);
         }
    }
