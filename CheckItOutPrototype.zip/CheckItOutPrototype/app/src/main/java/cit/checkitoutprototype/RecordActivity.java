package cit.checkitoutprototype;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.MediaController;
import android.widget.VideoView;

import static java.security.AccessController.getContext;

/**
 * Created by ocliv on 11/02/2017.
 */

public class RecordActivity extends Activity{

    static final int REQUEST_VIDEO_CAPTURE = 0;

    VideoView mVideoView = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mVideoView = (VideoView) findViewById(R.id.videoVieww);
        setContentView(R.layout.activity_record);

        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
        }
    }


        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
            if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK) {
                Uri videoUri = intent.getData();
                mVideoView.setVideoURI(videoUri);
                mVideoView.start();
            }
        }
    }
