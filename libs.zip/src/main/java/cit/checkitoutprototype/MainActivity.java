package cit.checkitoutprototype;

import android.app.Activity;
import android.content.ContentProvider;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.LoadBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegNotSupportedException;


public class MainActivity extends Activity{

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            FFmpeg ffmpeg = FFmpeg.getInstance(MainActivity.this);
            try {
                ffmpeg.loadBinary(new LoadBinaryResponseHandler() {

                    @Override
                    public void onStart() {}

                    @Override
                    public void onFailure() {}

                    @Override
                    public void onSuccess() {}

                    @Override
                    public void onFinish() {}
                });
            } catch (FFmpegNotSupportedException e) {
                Toast.makeText(MainActivity.this, "Erreur, FFMpeg non supporté", Toast.LENGTH_SHORT).show();
            }
        }

        public void ImportFile(View w){
            Intent intent = new Intent(MainActivity.this, ImportActivity.class);
            startActivity(intent);}
        public void RecordFile(View w){
            Intent intent = new Intent(MainActivity.this, RecordActivity.class);
            startActivity(intent);
         }
    }
