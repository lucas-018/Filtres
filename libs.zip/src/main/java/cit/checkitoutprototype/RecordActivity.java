package cit.checkitoutprototype;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Toast;
import android.widget.VideoView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.channels.FileChannel;

import static java.security.AccessController.getContext;


public class RecordActivity extends Activity{

    static final int REQUEST_VIDEO_CAPTURE = 0;

    VideoView mVideoView = null;
    Uri videoUri = null;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mVideoView = (VideoView) findViewById(R.id.videoVieww);
        setContentView(R.layout.activity_record);

        Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);

        Toast.makeText(RecordActivity.this, String.valueOf(Build.VERSION.SDK_INT) , Toast.LENGTH_SHORT).show();

        takeVideoIntent.putExtra(MediaStore.EXTRA_OUTPUT, videoUri);
        if (takeVideoIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takeVideoIntent, REQUEST_VIDEO_CAPTURE);
        }

    }


        @Override
        protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
            if (requestCode == REQUEST_VIDEO_CAPTURE && resultCode == RESULT_OK) {
                videoUri = intent.getData();

                Intent intentForFilterActivity = new Intent(RecordActivity.this, FilterActivity.class);
                intentForFilterActivity.putExtra("VideoToFilter", videoUri.getPath());
                startActivity(intentForFilterActivity);

            }
        }
}






