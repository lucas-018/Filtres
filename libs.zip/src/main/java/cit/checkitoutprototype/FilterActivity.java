package cit.checkitoutprototype;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.test.ActivityUnitTestCase;
import android.widget.Toast;

import com.github.hiteshsondhi88.libffmpeg.ExecuteBinaryResponseHandler;
import com.github.hiteshsondhi88.libffmpeg.FFmpeg;
import com.github.hiteshsondhi88.libffmpeg.exceptions.FFmpegCommandAlreadyRunningException;

import java.io.File;

/**
 * Created by ocliv on 12/02/2017.
 */

public class FilterActivity extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filter);

        Intent intentVideo = getIntent();
        String pathIn = intentVideo.getStringExtra("VideoToFilter");

        FFmpeg ffmpeg = FFmpeg.getInstance(FilterActivity.this);
        try {
            String[] cmdExtract = {"-i " + pathIn + " extracted.wav"};
            ffmpeg.execute(cmdExtract, new ExecuteBinaryResponseHandler() {

                @Override
                public void onStart() {}

                @Override
                public void onProgress(String message) {}

                @Override
                public void onFailure(String message) {
                    Toast.makeText(FilterActivity.this, "Failure!", Toast.LENGTH_SHORT).show();
                }

                @Override
                public void onSuccess(String message) {}

                @Override
                public void onFinish() {}
            });
        } catch (FFmpegCommandAlreadyRunningException e) {
        }
    }


}
