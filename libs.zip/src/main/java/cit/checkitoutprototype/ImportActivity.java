package cit.checkitoutprototype;

import android.app.Activity;
import android.content.CursorLoader;
import android.database.Cursor;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

/**
 * Created by ocliv on 11/02/2017.
 */


public class ImportActivity extends Activity{
/*
    Cursor cursor = null;
    ListView vue;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        vue = (ListView) findViewById(R.id.listView);

        String[] projection = {MediaStore.Video.Media._ID,MediaStore.Video.Media.DISPLAY_NAME,};

        cursor = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, projection, null, null, null);

        SimpleCursorAdapter adapter = new SimpleCursorAdapter (this, R.layout.cursor_row, cursor,
                new String[]{MediaStore.Video.Media.DISPLAY_NAME}, new int[]{R.id.salaire})



    }*/
}
